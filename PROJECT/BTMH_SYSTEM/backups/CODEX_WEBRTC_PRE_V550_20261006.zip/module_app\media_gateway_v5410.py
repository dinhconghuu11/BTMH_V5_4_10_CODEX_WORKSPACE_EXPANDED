from __future__ import annotations

import os
import base64
import json
import re
import secrets
import shutil
import socket
import subprocess
import threading
import time
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
from uuid import UUID, uuid4

from .config import CONFIG_DIR, DATA_ROOT, LOG_DIR
from .camera_profiles import normalize_camera_source


GATEWAY_VERSION = "1.21.1"
GATEWAY_PATH = "btmhmain"
# Signalling/control are always private. LAN clients use the authenticated app
# proxy; only the ICE media listener is allowed to bind network interfaces.
GATEWAY_HTTP_HOST = "127.0.0.1"
GATEWAY_HTTP_PORT = max(1024, min(65535, int(os.getenv("BTMH_MEDIA_GATEWAY_HTTP_PORT", "8889"))))
GATEWAY_ICE_PORT = max(1024, min(65535, int(os.getenv("BTMH_MEDIA_GATEWAY_ICE_PORT", "8189"))))
GATEWAY_API_PORT = max(1024, min(65535, int(os.getenv("BTMH_MEDIA_GATEWAY_API_PORT", "9997"))))
GATEWAY_METRICS_PORT = max(1024, min(65535, int(os.getenv("BTMH_MEDIA_GATEWAY_METRICS_PORT", "9998"))))
GATEWAY_ENABLED = os.getenv("BTMH_MEDIA_GATEWAY_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
GATEWAY_RTSP_PORT = max(1024, min(65535, int(os.getenv("BTMH_MEDIA_GATEWAY_RTSP_PORT", "8554"))))
WHEP_MAX_BODY = 65536
WHEP_MAX_SESSIONS = 32
WHEP_MAX_OWNER_SESSIONS = 8


class NativeGatewayError(RuntimeError):
    def __init__(self, status_code: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class NativeMediaGateway:
    """Own the local MediaMTX process used only for browser-native live video.

    Camera credentials are passed through the child process environment and are
    never written to the MediaMTX YAML file, browser storage or public API.
    FaceID/PAD keep their existing independent pipeline in V5.4.10.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._process: subprocess.Popen | None = None
        self._source = ""
        self._source_label = ""
        self._desired = False
        self._shutting_down = False
        self._restart_count = 0
        self._started_at = 0.0
        self._last_error = ""
        self._watchdog: threading.Thread | None = None
        self._log_thread: threading.Thread | None = None
        self._internal_user = "btmh-internal"
        self._internal_password = secrets.token_urlsafe(32)
        self._generation = 0
        self._sessions: dict[str, dict[str, Any]] = {}
        self._pending_sessions: dict[str, str] = {}
        self._next_restart_at = 0.0
        self._failure_count = 0
        self._source_error = ""
        self._diagnostics: dict[str, Any] = {}
        self._diagnostics_at = 0.0
        self._http = build_opener(ProxyHandler({}), _NoRedirect())
        self._runtime_dir = DATA_ROOT / "runtime" / "mediamtx"
        self._config_dir = CONFIG_DIR / "media_gateway"
        self._config_path = self._config_dir / "mediamtx_v5410.yml"
        self._log_path = LOG_DIR / "mediamtx-gateway.log"

    @staticmethod
    def _is_rtsp(source: str) -> bool:
        value = str(source or "").strip().lower()
        return value.startswith(("rtsp://", "rtsps://"))

    def binary_path(self) -> Path:
        configured = os.getenv("BTMH_MEDIAMTX_BINARY", "").strip()
        if configured:
            return Path(os.path.expandvars(os.path.expanduser(configured)))
        if os.name == "nt":
            return self._runtime_dir / "mediamtx.exe"
        found = shutil.which("mediamtx")
        return Path(found) if found else self._runtime_dir / "mediamtx"

    def _write_config(self) -> None:
        self._config_dir.mkdir(parents=True, exist_ok=True)
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        # Secrets intentionally do not appear here. MTX_PATHS_BTMHMAIN_SOURCE is
        # injected only into the child environment by _spawn_locked().
        lan = self._lan_mode()
        ice_host = "0.0.0.0" if lan else "127.0.0.1"
        hosts = self._additional_hosts()
        text = f"""# BTMH 5.4.10 native media gateway (secret-free configuration)
logLevel: info
logDestinations: [stdout]
authMethod: internal
authInternalUsers: []
api: true
apiAddress: {GATEWAY_HTTP_HOST}:{GATEWAY_API_PORT}
apiAllowOrigins: []
metrics: true
metricsAddress: {GATEWAY_HTTP_HOST}:{GATEWAY_METRICS_PORT}
metricsAllowOrigins: []
pprof: false
playback: false
rtsp: true
rtspAddress: {GATEWAY_HTTP_HOST}:{GATEWAY_RTSP_PORT}
rtspTransports: [tcp]
rtmp: false
hls: false
srt: false
moq: false
webrtc: true
webrtcAddress: {GATEWAY_HTTP_HOST}:{GATEWAY_HTTP_PORT}
webrtcEncryption: false
webrtcAllowOrigins: []
webrtcLocalUDPAddress: {ice_host}:{GATEWAY_ICE_PORT}
webrtcLocalTCPAddress: {ice_host}:{GATEWAY_ICE_PORT}
webrtcIPsFromInterfaces: {str(lan).lower()}
webrtcAdditionalHosts: {json.dumps(hosts)}
webrtcICEServers2: []
writeQueueSize: 128
paths:
  {GATEWAY_PATH}:
    source: publisher
    sourceOnDemand: true
    sourceOnDemandStartTimeout: 8s
    sourceOnDemandCloseAfter: 5s
    rtspTransport: tcp
"""
        current = self._config_path.read_text(encoding="utf-8", errors="ignore") if self._config_path.exists() else ""
        if current != text:
            self._config_path.write_text(text, encoding="utf-8")

    @staticmethod
    def _lan_mode() -> bool:
        return (os.getenv("MODULE_HOST", "127.0.0.1").strip() in {"0.0.0.0", "::"}
                or os.getenv("BTMH_NETWORK_MODE", "local").strip().lower() == "lan")

    @staticmethod
    def _additional_hosts() -> list[str]:
        hosts = ["127.0.0.1"]
        for value in os.getenv("BTMH_MEDIA_GATEWAY_ICE_HOSTS", "").split(","):
            value = value.strip()
            # Hostnames/IPs only: never accept URLs or YAML fragments.
            if value and re.fullmatch(r"[a-zA-Z0-9_.:\-]+", value) and value not in hosts:
                hosts.append(value)
        return hosts[:16]

    def _child_environment(self, source: str) -> dict[str, str]:
        # v1.21.1 uses indexed variables for arrays of structures, not JSON.
        env = {key: value for key, value in os.environ.items() if not key.startswith("MTX_")}
        env["MTX_PATHS_BTMHMAIN_SOURCE"] = source
        env["MTX_PATHS_BTMHMAIN_RTSPTRANSPORT"] = "tcp"
        env["MTX_AUTHINTERNALUSERS_0_USER"] = self._internal_user
        env["MTX_AUTHINTERNALUSERS_0_PASS"] = self._internal_password
        env["MTX_AUTHINTERNALUSERS_0_IPS"] = "127.0.0.1,::1"
        for index, action in enumerate(("read", "api", "metrics")):
            env[f"MTX_AUTHINTERNALUSERS_0_PERMISSIONS_{index}_ACTION"] = action
            env[f"MTX_AUTHINTERNALUSERS_0_PERMISSIONS_{index}_PATH"] = GATEWAY_PATH if action == "read" else ""
        return env

    @staticmethod
    def _yaml_quote(value: str) -> str:
        # JSON-style quoting is valid YAML and safely preserves Windows paths.
        import json
        return json.dumps(str(value), ensure_ascii=False)


    @staticmethod
    def _redact_gateway_log_line(line: str, source: str) -> str:
        """Keep gateway diagnostics useful without ever persisting RTSP userinfo."""
        clean = str(line or "")
        if source:
            clean = clean.replace(source, "[RTSP_SOURCE_REDACTED]")
        # Also redact any RTSP(S) userinfo MediaMTX might include in an error.
        clean = re.sub(r"(?i)(rtsps?://)[^\s/]+@", r"\1***@", clean)
        return clean

    def _safe_message(self, message: str, source: str = "", password: str = "") -> str:
        clean = self._redact_gateway_log_line(message, source or self._source)
        for value in (password, self._internal_password):
            if value:
                clean = clean.replace(value, "[INTERNAL_SECRET_REDACTED]")
                token = base64.b64encode(f"{self._internal_user}:{value}".encode()).decode()
                clean = clean.replace(token, "[INTERNAL_AUTH_REDACTED]")
        clean = re.sub(r"(?i)(/whep/)[0-9a-f-]{36}", r"\1[SESSION_REDACTED]", clean)
        return clean.strip()[:1000]

    def _start_log_pump(self, proc: subprocess.Popen, source: str) -> None:
        pipe = proc.stdout
        password = self._internal_password
        if pipe is None:
            return

        def pump() -> None:
            try:
                with open(self._log_path, "a", encoding="utf-8", errors="replace") as log:
                    while True:
                        raw = pipe.readline()
                        if not raw:
                            break
                        if isinstance(raw, bytes):
                            line = raw.decode("utf-8", errors="replace")
                        else:
                            line = str(raw)
                        safe = self._safe_message(line, source, password)
                        if re.search(r"\b(ERR|ERROR)\b", safe, re.IGNORECASE):
                            # Do not wait for the startup lock: a failed child
                            # must deliver its precise error before poll() exits.
                            if self._process is proc:
                                self._last_error = safe
                                if "RTSP source" in safe:
                                    self._source_error = safe
                        log.write(safe + "\n")
                        log.flush()
            except Exception:
                pass
            finally:
                try:
                    pipe.close()
                except Exception:
                    pass

        self._log_thread = threading.Thread(target=pump, name="btmh-mediamtx-log", daemon=True)
        self._log_thread.start()

    @staticmethod
    def _port_open(host: str, port: int, timeout: float = 0.25) -> bool:
        try:
            with socket.create_connection((host, int(port)), timeout=timeout):
                return True
        except OSError:
            return False

    def _spawn_locked(self) -> bool:
        source = normalize_camera_source(self._source)
        if not self._desired or not self._is_rtsp(source):
            return False
        binary = self.binary_path()
        if not binary.exists():
            self._last_error = f"MediaMTX {GATEWAY_VERSION} chưa được cài trong runtime cục bộ"
            self._schedule_retry_locked()
            return False
        if any(self._port_open(GATEWAY_HTTP_HOST, port, 0.05)
               for port in (GATEWAY_HTTP_PORT, GATEWAY_API_PORT, GATEWAY_RTSP_PORT)):
            self._last_error = "MEDIA_GATEWAY_PORT_BUSY: cổng gateway đã được tiến trình khác sử dụng"
            self._schedule_retry_locked()
            return False
        # A previous recorder must never reconnect to a different camera under
        # its old source label after handover. Rotate auth on every child start.
        self._internal_password = secrets.token_urlsafe(32)
        self._generation += 1
        self._sessions.clear()
        self._pending_sessions.clear()
        self._diagnostics = {}
        self._diagnostics_at = 0.0
        self._source_error = ""
        # Reset before starting the pump: a child that fails immediately may
        # already have delivered its precise startup error when Popen returns.
        self._last_error = ""
        self._write_config()
        env = self._child_environment(source)
        creationflags = 0
        startupinfo = None
        if os.name == "nt":
            creationflags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0)) | int(getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        try:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)
            proc = subprocess.Popen(
                [str(binary), str(self._config_path)],
                cwd=str(self._runtime_dir if self._runtime_dir.exists() else binary.parent),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                creationflags=creationflags,
                startupinfo=startupinfo,
            )
            self._process = proc
            self._start_log_pump(proc, source)
            self._started_at = time.time()
            deadline = time.monotonic() + 4.0
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    if self._log_thread:
                        self._log_thread.join(timeout=0.2)
                    self._last_error = self._last_error or f"MediaMTX thoát sớm với mã {proc.returncode}; xem mediamtx-gateway.log"
                    self._process = None
                    self._schedule_retry_locked()
                    return False
                if (self._port_open(GATEWAY_HTTP_HOST, GATEWAY_HTTP_PORT)
                        and self._port_open(GATEWAY_HTTP_HOST, GATEWAY_API_PORT)):
                    self._failure_count = 0
                    self._next_restart_at = 0.0
                    return True
                time.sleep(0.08)
            self._last_error = "MEDIA_GATEWAY_START_TIMEOUT: listener chưa sẵn sàng sau 4 giây"
            self._stop_locked()
            self._schedule_retry_locked()
            return False
        except Exception as exc:
            self._process = None
            self._last_error = self._safe_message(f"{type(exc).__name__}: {exc}")
            self._schedule_retry_locked()
            return False

    def _schedule_retry_locked(self) -> None:
        self._failure_count += 1
        self._next_restart_at = time.monotonic() + min(30.0, 1.5 * 2 ** min(self._failure_count - 1, 5))

    def _stop_locked(self) -> None:
        proc = self._process
        self._process = None
        self._generation += 1
        self._sessions.clear()
        self._pending_sessions.clear()
        self._diagnostics = {}
        self._diagnostics_at = 0.0
        if proc is None:
            return
        try:
            if proc.poll() is None:
                proc.terminate()
                proc.wait(timeout=3.0)
        except Exception:
            try:
                proc.kill()
                proc.wait(timeout=1.5)
            except Exception:
                pass

    def _ensure_watchdog_locked(self) -> None:
        if self._watchdog and self._watchdog.is_alive():
            return
        self._watchdog = threading.Thread(target=self._watchdog_loop, name="btmh-media-gateway-watchdog", daemon=True)
        self._watchdog.start()

    def _watchdog_loop(self) -> None:
        while True:
            time.sleep(1.5)
            with self._lock:
                if self._shutting_down:
                    return
                if not self._desired:
                    continue
                proc = self._process
                if proc is not None and proc.poll() is None:
                    self._refresh_diagnostics_locked()
                    continue
                self._process = None
                if time.monotonic() < self._next_restart_at:
                    continue
                self._restart_count += 1
                self._spawn_locked()

    def start(self, source: str, source_label: str = "") -> dict[str, Any]:
        with self._lock:
            self._shutting_down = False
            self._source = normalize_camera_source(str(source or ""))
            self._source_label = str(source_label or "").strip()
            self._desired = bool(GATEWAY_ENABLED and self._is_rtsp(self._source))
            self._failure_count = 0
            self._next_restart_at = 0.0
            self._stop_locked()
            ok = self._spawn_locked() if self._desired else False
            self._ensure_watchdog_locked()
            return self.status(_already_locked=True) | {"started": bool(ok)}

    def sync_source(self, source: str, source_label: str = "") -> dict[str, Any]:
        clean = normalize_camera_source(str(source or ""))
        label = str(source_label or "").strip()
        with self._lock:
            desired = bool(GATEWAY_ENABLED and self._is_rtsp(clean))
            proc_alive = self._process is not None and self._process.poll() is None
            if clean == self._source and label == self._source_label and desired == self._desired and (proc_alive or not desired):
                return self.status(_already_locked=True)
            self._source = clean
            self._source_label = label
            self._desired = desired
            self._failure_count = 0
            self._next_restart_at = 0.0
            self._stop_locked()
            self._next_restart_at = 0.0
            ok = self._spawn_locked() if desired else False
            self._ensure_watchdog_locked()
            return self.status(_already_locked=True) | {"started": bool(ok)}

    def restart(self) -> dict[str, Any]:
        with self._lock:
            self._stop_locked()
            ok = self._spawn_locked() if self._desired else False
            if self._desired:
                self._restart_count += 1
            return self.status(_already_locked=True) | {"started": bool(ok)}

    def stop(self) -> None:
        with self._lock:
            self._desired = False
            self._stop_locked()

    def shutdown(self) -> None:
        with self._lock:
            self._shutting_down = True
            self._desired = False
            self._stop_locked()

    def _http_request(self, method: str, url: str, body: bytes | None = None,
                      timeout: float = 0.4, password: str = "") -> tuple[int, dict[str, str], bytes]:
        auth = base64.b64encode(f"{self._internal_user}:{password or self._internal_password}".encode()).decode()
        headers = {"Authorization": f"Basic {auth}", "Accept": "application/json"}
        if body is not None:
            headers.update({"Content-Type": "application/sdp", "Accept": "application/sdp"})
        request = Request(url, data=body, headers=headers, method=method)
        try:
            try:
                response = self._http.open(request, timeout=timeout)
            except HTTPError as exc:
                response = exc
            with response:
                payload = response.read(WHEP_MAX_BODY + 1)
                if len(payload) > WHEP_MAX_BODY:
                    raise NativeGatewayError(502, "GATEWAY_RESPONSE_TOO_LARGE", "MediaMTX trả dữ liệu vượt giới hạn")
                return int(response.code), dict(response.headers.items()), payload
        except NativeGatewayError:
            raise
        except (OSError, URLError, TimeoutError) as exc:
            message = self._safe_message(f"MEDIA_GATEWAY_UNREACHABLE: {type(exc).__name__}: {exc}", password=password)
            raise NativeGatewayError(503, "GATEWAY_UNREACHABLE", message) from None

    @staticmethod
    def _header(headers: dict[str, str], name: str) -> str:
        return next((value for key, value in headers.items() if key.lower() == name.lower()), "")

    def _upstream_error(self, status: int, payload: bytes, password: str = "") -> NativeGatewayError:
        try:
            detail = json.loads(payload).get("error") or ""
        except (ValueError, AttributeError):
            detail = payload.decode("utf-8", errors="replace")
        message = self._safe_message(f"MediaMTX WHEP HTTP {status}: {detail}", password=password)
        with self._lock:
            self._last_error = message
        return NativeGatewayError(503 if status >= 500 else 502, "GATEWAY_WHEP_REJECTED", message)

    def _validate_session_location(self, value: str) -> str:
        base = f"http://{GATEWAY_HTTP_HOST}:{GATEWAY_HTTP_PORT}/{GATEWAY_PATH}/whep"
        url = urljoin(base, value)
        try:
            parts = urlsplit(url)
            prefix = f"/{GATEWAY_PATH}/whep/"
            suffix = parts.path[len(prefix):] if parts.path.startswith(prefix) else ""
            valid_id = str(UUID(suffix)) == suffix.lower()
            if (parts.scheme == "http" and parts.hostname == GATEWAY_HTTP_HOST
                    and parts.port == GATEWAY_HTTP_PORT and not parts.username and not parts.password
                    and not parts.query and not parts.fragment and valid_id):
                return url
        except (ValueError, TypeError):
            pass
        raise NativeGatewayError(502, "GATEWAY_INVALID_LOCATION", "MediaMTX trả session Location không hợp lệ")

    def create_whep_session(self, sdp: str, owner: str, *, expected_source: str | None = None) -> dict[str, str]:
        """Proxy bounded SDP negotiation; the browser gets only an app session ID."""
        if not str(owner or "").strip():
            raise NativeGatewayError(401, "SESSION_OWNER_REQUIRED", "Thiếu phiên đăng nhập")
        body = str(sdp or "").encode("utf-8")
        if len(body) > WHEP_MAX_BODY:
            raise NativeGatewayError(413, "SDP_TOO_LARGE", "SDP vượt giới hạn 64 KiB")
        if not body.startswith(b"v=0"):
            raise NativeGatewayError(400, "INVALID_SDP", "SDP offer không hợp lệ")
        session_id = str(uuid4())
        with self._lock:
            if expected_source is not None and normalize_camera_source(expected_source) != self._source:
                raise NativeGatewayError(409, "GATEWAY_SOURCE_CHANGED", "Gateway đang chuyển sang camera được chọn")
            if not self._ready_locked():
                raise NativeGatewayError(503, "GATEWAY_NOT_READY", self._last_error or "MediaMTX chưa sẵn sàng")
            owners = [item["owner"] for item in self._sessions.values()] + list(self._pending_sessions.values())
            if len(owners) >= WHEP_MAX_SESSIONS or owners.count(owner) >= WHEP_MAX_OWNER_SESSIONS:
                raise NativeGatewayError(429, "GATEWAY_SESSION_LIMIT", "Đã đạt giới hạn phiên Live View")
            generation = self._generation
            password = self._internal_password
            self._pending_sessions[session_id] = owner
        upstream_url = ""
        try:
            status, headers, answer = self._http_request(
                "POST", f"http://{GATEWAY_HTTP_HOST}:{GATEWAY_HTTP_PORT}/{GATEWAY_PATH}/whep",
                body, timeout=10.0, password=password)
            if status != 201:
                raise self._upstream_error(status, answer, password)
            upstream_url = self._validate_session_location(self._header(headers, "Location"))
            if (self._header(headers, "Content-Type").split(";", 1)[0].strip().lower() != "application/sdp"
                    or not answer.startswith(b"v=0")):
                raise NativeGatewayError(502, "GATEWAY_INVALID_SDP", "MediaMTX trả SDP answer không hợp lệ")
            answer_text = answer.decode("utf-8", errors="strict")
            with self._lock:
                if generation != self._generation or not self._desired or self._shutting_down:
                    raise NativeGatewayError(409, "GATEWAY_SOURCE_CHANGED", "Camera đã thay đổi trong lúc khởi tạo video")
                upstream_id = self._header(headers, "ID")
                self._sessions[session_id] = {"owner": owner, "url": upstream_url,
                                              "upstream_id": upstream_id, "created": time.monotonic(),
                                              "password": password}
            return {"sdp": answer_text, "session_id": session_id}
        except UnicodeDecodeError:
            raise NativeGatewayError(502, "GATEWAY_INVALID_SDP", "SDP answer không có mã hóa UTF-8 hợp lệ") from None
        except NativeGatewayError as exc:
            with self._lock:
                self._last_error = self._safe_message(str(exc), password=password)
            raise
        finally:
            with self._lock:
                self._pending_sessions.pop(session_id, None)
                kept = session_id in self._sessions
            if upstream_url and not kept:
                try:
                    self._http_request("DELETE", upstream_url, timeout=0.5, password=password)
                except NativeGatewayError:
                    pass

    def delete_whep_session(self, session_id: str, owner: str) -> bool:
        with self._lock:
            session = self._sessions.get(str(session_id))
            if session is None:
                return False
            if session["owner"] != owner:
                raise NativeGatewayError(403, "SESSION_OWNER_MISMATCH", "Phiên video thuộc người dùng khác")
        status, _, body = self._http_request("DELETE", session["url"], timeout=1.0, password=session["password"])
        if status not in {200, 204, 404}:
            raise self._upstream_error(status, body, session["password"])
        with self._lock:
            if self._sessions.get(str(session_id)) is session:
                self._sessions.pop(str(session_id), None)
        return True

    def _ready_locked(self) -> bool:
        return bool(self._desired and self._process is not None and self._process.poll() is None
                    and self._port_open(GATEWAY_HTTP_HOST, GATEWAY_HTTP_PORT, 0.08))

    def relay_source(self, source: str) -> str:
        """Private recorder input; never serialize or log this credentialed URI."""
        with self._lock:
            if (normalize_camera_source(str(source or "")) != self._source or not self._ready_locked()
                    or not self._port_open(GATEWAY_HTTP_HOST, GATEWAY_RTSP_PORT, 0.08)):
                return ""
            return f"rtsp://{self._internal_user}:{self._internal_password}@{GATEWAY_HTTP_HOST}:{GATEWAY_RTSP_PORT}/{GATEWAY_PATH}"

    def _api_json(self, path: str) -> dict[str, Any]:
        status, _, body = self._http_request("GET", f"http://{GATEWAY_HTTP_HOST}:{GATEWAY_API_PORT}{path}")
        if status != 200:
            raise NativeGatewayError(503, "GATEWAY_API_ERROR", f"MediaMTX diagnostics HTTP {status}")
        try:
            value = json.loads(body)
            if isinstance(value, dict):
                return value
        except ValueError:
            pass
        raise NativeGatewayError(503, "GATEWAY_API_INVALID", "MediaMTX diagnostics không hợp lệ")

    @staticmethod
    def _count(value: Any) -> int:
        try:
            return max(0, int(value or 0))
        except (ValueError, TypeError):
            return 0

    def _refresh_diagnostics_locked(self) -> None:
        now = time.monotonic()
        if now - self._diagnostics_at < 2.0:
            return
        self._diagnostics_at = now
        try:
            path = self._api_json(f"/v3/paths/get/{GATEWAY_PATH}")
            sessions = self._api_json("/v3/webrtc/sessions/list?itemsPerPage=100").get("items", [])
            sessions = [item for item in sessions if isinstance(item, dict) and item.get("path") == GATEWAY_PATH]
            codecs = []
            for track in path.get("tracks2") or []:
                if not isinstance(track, dict):
                    continue
                codec = str(track.get("codec") or "")
                if not re.fullmatch(r"[A-Za-z0-9]{1,20}", codec):
                    continue
                props = track.get("codecProps") or {}
                item = {"codec": codec}
                for key in ("width", "height"):
                    if key in props:
                        item[key] = self._count(props[key])
                for key in ("profile", "level"):
                    value = str(props.get(key) or "")
                    if re.fullmatch(r"[A-Za-z0-9 ._-]{1,40}", value):
                        item[key] = value
                codecs.append(item)
            # In v1.21.1 an on-demand static source can have online=true while
            # its handler exists but no stream is available yet. Require the
            # stream's availability as well; a listening gateway is not proof
            # that the upstream camera is delivering media.
            source_ready = bool(path.get("available", path.get("ready", False))
                                and path.get("online", True))
            if source_ready:
                # An old connection error must not turn a healthy source's
                # subsequent on-demand idle state into a permanent failure.
                self._source_error = ""
            readers = len(path.get("readers") or [])
            source_state = "READY" if source_ready else (
                "ERROR" if self._source_error else ("CONNECTING" if readers or self._pending_sessions else "IDLE"))
            self._diagnostics = {
                "api_ready": True, "source_healthy": source_ready if source_state != "IDLE" else None,
                "source_state": source_state, "source_on_demand": True, "source_codecs": codecs,
                "source_inbound_bytes": self._count(path.get("inboundBytes", path.get("bytesReceived"))),
                "source_frames_in_error": self._count(path.get("inboundFramesInError")),
                "source_reader_count": readers, "webrtc_session_count": len(sessions),
                "webrtc_connected_count": sum(bool(item.get("peerConnectionEstablished")) for item in sessions),
                "source_error": "" if source_ready else self._source_error,
                "diagnostics_error": "", "diagnostics_updated_at": time.time(),
            }
            # Closed browser peers disappear in MediaMTX. Bound app metadata too,
            # while allowing up to 30 seconds for a new negotiation to appear.
            live_ids = {str(item.get("id") or "") for item in sessions}
            for sid, session in list(self._sessions.items()):
                age = now - session["created"]
                if age > 30 and session["upstream_id"] and session["upstream_id"] not in live_ids:
                    self._sessions.pop(sid, None)
                elif age > 43200:
                    # One expiration per poll keeps diagnostics work bounded.
                    self.delete_whep_session(sid, session["owner"])
                    break
        except NativeGatewayError as exc:
            self._diagnostics = {"api_ready": False, "source_healthy": None, "source_state": "UNKNOWN",
                                 "diagnostics_error": self._safe_message(str(exc)), "source_error": self._source_error}

    def status(self, _already_locked: bool = False) -> dict[str, Any]:
        if not _already_locked:
            with self._lock:
                return self.status(_already_locked=True)
        proc = self._process
        alive = bool(proc is not None and proc.poll() is None)
        port_ready = bool(alive and self._port_open(GATEWAY_HTTP_HOST, GATEWAY_HTTP_PORT, 0.08))
        if alive and port_ready:
            self._refresh_diagnostics_locked()
        source_kind = "rtsp" if self._is_rtsp(self._source) else ("local" if self._source else "none")
        return {
            "enabled": bool(GATEWAY_ENABLED),
            "available": bool(self._desired and alive and port_ready),
            "process_alive": alive,
            "port_ready": port_ready,
            "binary_present": self.binary_path().exists(),
            "version": GATEWAY_VERSION,
            "transport": "NATIVE_GATEWAY_WEBRTC",
            "path": GATEWAY_PATH,
            "whep_url": "/api/v1/media/gateway/whep" if self._desired else "",
            "source_kind": source_kind,
            "source_label": self._safe_message(self._source_label),
            "pid": int(proc.pid) if alive and proc is not None else 0,
            "restart_count": int(self._restart_count),
            "started_at": float(self._started_at),
            "last_error": self._safe_message(self._last_error),
            "restart_backoff_ms": max(0, int((self._next_restart_at - time.monotonic()) * 1000)),
            "lan_media": self._lan_mode(),
            "ice_port": GATEWAY_ICE_PORT,
            "signalling_auth": "APPLICATION_RBAC_PROXY",
            "recorder_relay_available": bool(alive and self._port_open(GATEWAY_HTTP_HOST, GATEWAY_RTSP_PORT, 0.08)),
            "app_session_count": len(self._sessions),
            "pending_session_count": len(self._pending_sessions),
            "api_ready": False,
            "source_healthy": None,
            "source_state": "UNKNOWN" if alive else "STOPPED",
            "source_codecs": [],
            "source_error": self._source_error,
            "diagnostics_error": "",
            "secret_on_disk": False,
            "ai_independent": True,
            **self._diagnostics,
        }


MEDIA_GATEWAY = NativeMediaGateway()
