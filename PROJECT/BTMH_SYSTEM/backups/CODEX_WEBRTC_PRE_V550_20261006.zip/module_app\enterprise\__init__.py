"""CampusFace Enterprise Camera Layer"""
