"""Auxiliary live-grid decoders with handover reservations and bounded shutdown."""
from __future__ import annotations
from contextlib import contextmanager
from dataclasses import dataclass, field
import threading
import time
from typing import Any
import cv2
from .capture_session_v544 import CaptureSession


@dataclass
class FleetWorker:
    camera_id: int
    source: Any
    name: str
    target_fps: float = 8.
    lock: threading.RLock = field(default_factory=threading.RLock)
    thread: threading.Thread | None = None
    running: bool = False
    latest_jpeg: bytes | None = None
    latest_at: float = 0.
    frame_seq: int = 0
    opened: bool = False
    error: str = ""
    reconnects: int = 0
    session: Any = None
    stopped: threading.Event = field(default_factory=threading.Event)

    def start(self):
        with self.lock:
            if self.error in {"AUTH_FAILED", "PATH_NOT_FOUND", "MASKED_CREDENTIALS"}:
                return  # Source edit or explicit preflight/stop clears this worker.
            if self.thread and self.thread.is_alive(): return
            self.running = True
            self.stopped.clear()
            self.thread = threading.Thread(target=self._run,name=f"btmh-fleet-{self.camera_id}",daemon=True)
            self.thread.start()

    def stop(self, *, wait=True, timeout=6.5):
        self.running = False
        self.stopped.set()
        with self.lock:
            session = self.session
        if session: session.close()
        if wait and self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=min(2., max(.1, timeout)))

    def status(self):
        with self.lock:
            age = max(0., time.time() - self.latest_at) if self.latest_at else None
            return dict(online=bool(self.running and self.opened and self.latest_jpeg and age is not None and age<4.),
                        last_frame_age_sec=round(age,2) if age is not None else None,
                        error=self.error,reconnects=self.reconnects,frame_seq=self.frame_seq)

    def jpeg(self):
        with self.lock: return self.latest_jpeg

    def _run(self):
        from .camera import StaticCameraService
        from dataclasses import asdict
        try:
            while self.running:
                src = int(self.source) if str(self.source).isdigit() else self.source
                session = CaptureSession(str(self.source),plans=[asdict(p) for p in StaticCameraService.capture_plans(src)],output_fps=self.target_fps)
                with self.lock:
                    self.session = session
                if not self.running:
                    session.close(); break
                try:
                    session.start()
                    ready = session.wait_ready(3, 18., cancelled=self.stopped.is_set)
                    if not ready["ok"]:
                        self.error = ready["code"]; self.opened = False; self.reconnects += 1
                        # Wrong credentials/path need an operator correction, not a retry storm.
                        if ready["code"] in {"AUTH_FAILED","PATH_NOT_FOUND","MASKED_CREDENTIALS"}: break
                    else:
                        seq = -1
                        while self.running:
                            p = session.snapshot()
                            if not session.alive() or (p.at and time.perf_counter()-p.at>4.5): break
                            if p.frame is not None and p.seq != seq:
                                frame = p.frame
                                if frame.shape[1]>1280:
                                    frame=cv2.resize(frame,(1280,round(frame.shape[0]*1280/frame.shape[1])))
                                ok,buf=cv2.imencode('.jpg',frame,[cv2.IMWRITE_JPEG_QUALITY,82])
                                if ok:
                                    with self.lock:
                                        self.latest_jpeg=buf.tobytes();self.latest_at=time.time()
                                        self.frame_seq+=1;self.opened=True;self.error=""
                                seq=p.seq
                            self.stopped.wait(.02)
                finally:
                    session.close()
                    with self.lock:
                        if self.session is session: self.session=None
                    self.opened=False
                if self.stopped.wait(1.5): break
        except Exception:
            self.error="DECODER_ERROR"; self.opened=False
        finally:
            self.running=False


class CameraFleetV4:
    def __init__(self):
        self.lock=threading.RLock()
        self.workers: dict[int,FleetWorker]={}
        self._reserved: dict[int,int]={}

    def ensure(self,camera_id,source,name):
        cid=int(camera_id)
        with self.lock:
            worker=self.workers.get(cid)
            if worker and str(worker.source)!=str(source):
                worker.stop();worker=None
            if worker is None:
                worker=FleetWorker(cid,source,name);self.workers[cid]=worker
            if not self._reserved.get(cid): worker.start()
            else: worker.error="HANDOVER_RESERVED"
            return worker

    def get(self,camera_id):
        with self.lock:return self.workers.get(int(camera_id))

    def stop(self,camera_id,*,wait=True,timeout=6.5):
        with self.lock:worker=self.workers.pop(int(camera_id),None)
        if worker is None:return True
        worker.stop(wait=wait,timeout=timeout)
        return not bool(worker.thread and worker.thread.is_alive())

    @contextmanager
    def reserve(self,camera_id):
        if camera_id is None:
            yield;return
        cid=int(camera_id)
        with self.lock:self._reserved[cid]=self._reserved.get(cid,0)+1
        try:
            self.stop(cid,wait=True,timeout=2.)
            yield
        finally:
            with self.lock:
                self._reserved[cid]=self._reserved.get(cid,1)-1
                if self._reserved[cid]<=0:self._reserved.pop(cid,None)

    def shutdown(self):
        with self.lock:
            workers=list(self.workers.values());self.workers.clear()
        for worker in workers:worker.stop()


FLEET_V4=CameraFleetV4()
