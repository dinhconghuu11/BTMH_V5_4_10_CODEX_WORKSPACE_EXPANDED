from __future__ import annotations

import json
import math
import zipfile
from calendar import monthrange
from datetime import date, datetime, time, timedelta, timezone
from html import escape
from io import BytesIO
from typing import Any
from zoneinfo import ZoneInfo

from .db import execute, fetchall, fetchone, utc_now

VN_TZ = ZoneInfo("Asia/Ho_Chi_Minh")
SHIFT_KEY = "hr_shift_policy_v212"

DEFAULT_SHIFT_POLICY = {
    "enabled": False,
    "name": "Ca hành chính",
    "start_time": "08:00",
    "end_time": "17:30",
    "break_start": "12:00",
    "break_end": "13:30",
    "late_grace_minutes": 10,
    "early_leave_grace_minutes": 10,
    "workdays": [0, 1, 2, 3, 4],
}


def _parse_dt(value: Any) -> datetime | None:
    try:
        text = str(value or "").strip().replace("Z", "+00:00")
        if not text:
            return None
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _parse_hhmm(value: str, fallback: str) -> tuple[int, int]:
    try:
        parts = str(value or fallback).strip().split(":")
        h, m = int(parts[0]), int(parts[1])
        if not (0 <= h <= 23 and 0 <= m <= 59):
            raise ValueError
        return h, m
    except Exception:
        h, m = fallback.split(":")
        return int(h), int(m)


def _clean_policy(values: dict | None) -> dict:
    raw = {**DEFAULT_SHIFT_POLICY, **(values or {})}
    workdays = []
    for item in raw.get("workdays") or DEFAULT_SHIFT_POLICY["workdays"]:
        try:
            n = int(item)
            if 0 <= n <= 6 and n not in workdays:
                workdays.append(n)
        except Exception:
            continue
    if not workdays:
        workdays = list(DEFAULT_SHIFT_POLICY["workdays"])
    sh, sm = _parse_hhmm(str(raw.get("start_time") or ""), "08:00")
    eh, em = _parse_hhmm(str(raw.get("end_time") or ""), "17:30")
    bh, bm = _parse_hhmm(str(raw.get("break_start") or ""), "12:00")
    ch, cm = _parse_hhmm(str(raw.get("break_end") or ""), "13:30")
    return {
        "enabled": bool(raw.get("enabled")),
        "name": str(raw.get("name") or "Ca hành chính").strip()[:80] or "Ca hành chính",
        "start_time": f"{sh:02d}:{sm:02d}",
        "end_time": f"{eh:02d}:{em:02d}",
        "break_start": f"{bh:02d}:{bm:02d}",
        "break_end": f"{ch:02d}:{cm:02d}",
        "late_grace_minutes": max(0, min(180, int(raw.get("late_grace_minutes") or 0))),
        "early_leave_grace_minutes": max(0, min(180, int(raw.get("early_leave_grace_minutes") or 0))),
        "workdays": sorted(workdays),
    }


def shift_policy() -> dict:
    row = fetchone("SELECT setting_value FROM runtime_settings WHERE setting_key=?", (SHIFT_KEY,))
    if not row:
        return dict(DEFAULT_SHIFT_POLICY)
    try:
        data = json.loads(str(row.get("setting_value") or "{}")) or {}
    except Exception:
        data = {}
    return _clean_policy(data)


def save_shift_policy(values: dict) -> dict:
    clean = _clean_policy(values)
    now = utc_now()
    payload = json.dumps(clean, ensure_ascii=False, separators=(",", ":"))
    if fetchone("SELECT setting_key FROM runtime_settings WHERE setting_key=?", (SHIFT_KEY,)):
        execute("UPDATE runtime_settings SET setting_value=?,updated_at=? WHERE setting_key=?", (payload, now, SHIFT_KEY))
    else:
        execute("INSERT INTO runtime_settings(setting_key,setting_value,updated_at) VALUES(?,?,?)", (SHIFT_KEY, payload, now))
    return clean


def _period_range(period: str, anchor: str | None = None) -> tuple[datetime, datetime, date, str]:
    p = str(period or "day").lower().strip()
    if p not in {"day", "week", "month"}:
        p = "day"
    try:
        d = date.fromisoformat(str(anchor or ""))
    except Exception:
        d = datetime.now(VN_TZ).date()
    if p == "week":
        start_date = d - timedelta(days=d.weekday())
        end_date = start_date + timedelta(days=7)
        label = f"{start_date.strftime('%d/%m/%Y')} - {(end_date - timedelta(days=1)).strftime('%d/%m/%Y')}"
    elif p == "month":
        start_date = d.replace(day=1)
        days = monthrange(start_date.year, start_date.month)[1]
        end_date = start_date + timedelta(days=days)
        label = start_date.strftime("Tháng %m/%Y")
    else:
        start_date = d
        end_date = d + timedelta(days=1)
        label = d.strftime("%d/%m/%Y")
    start_local = datetime.combine(start_date, time.min, VN_TZ)
    end_local = datetime.combine(end_date, time.min, VN_TZ)
    return start_local.astimezone(timezone.utc), end_local.astimezone(timezone.utc), start_date, label


def _day_bounds(d: date) -> tuple[datetime, datetime]:
    a = datetime.combine(d, time.min, VN_TZ)
    return a, a + timedelta(days=1)


def _split_local_days(start_utc: datetime, end_utc: datetime) -> list[tuple[date, datetime, datetime]]:
    if end_utc <= start_utc:
        return []
    start_local = start_utc.astimezone(VN_TZ)
    end_local = end_utc.astimezone(VN_TZ)
    out = []
    current = start_local.date()
    while current <= end_local.date():
        ds, de = _day_bounds(current)
        seg_start = max(start_local, ds)
        seg_end = min(end_local, de)
        if seg_end > seg_start:
            out.append((current, seg_start, seg_end))
        current += timedelta(days=1)
    return out


def _shift_times_for_day(d: date, policy: dict) -> dict:
    sh, sm = _parse_hhmm(policy["start_time"], "08:00")
    eh, em = _parse_hhmm(policy["end_time"], "17:30")
    bh, bm = _parse_hhmm(policy["break_start"], "12:00")
    ch, cm = _parse_hhmm(policy["break_end"], "13:30")
    start = datetime.combine(d, time(sh, sm), VN_TZ)
    end = datetime.combine(d, time(eh, em), VN_TZ)
    if end <= start:
        end += timedelta(days=1)
    break_start = datetime.combine(d, time(bh, bm), VN_TZ)
    break_end = datetime.combine(d, time(ch, cm), VN_TZ)
    break_sec = max(0.0, (break_end - break_start).total_seconds()) if start <= break_start < break_end <= end else 0.0
    expected = max(0.0, (end - start).total_seconds() - break_sec)
    return {"start": start, "end": end, "expected_sec": expected}


def _fmt_seconds(seconds: float) -> str:
    total = max(0, int(round(float(seconds or 0))))
    h, rem = divmod(total, 3600)
    m, _ = divmod(rem, 60)
    return f"{h}h {m:02d}p"


def _fmt_time(dt: datetime | None) -> str:
    return dt.astimezone(VN_TZ).strftime("%H:%M") if dt else "—"


def build_hr_report(period: str = "day", anchor: str | None = None) -> dict:
    start_utc, end_utc, start_date, label = _period_range(period, anchor)
    now_utc = datetime.now(timezone.utc)
    effective_end = min(end_utc, now_utc) if start_utc <= now_utc else end_utc
    policy = shift_policy()

    employees = fetchall("SELECT id,student_code,full_name,class_name,faculty FROM students ORDER BY full_name,student_code")
    sessions = fetchall(
        """SELECT id,student_id,camera_source,started_at,last_seen_at,ended_at,duration_sec,status,start_reason,end_reason
        FROM hr_presence_sessions
        WHERE started_at<? AND COALESCE(ended_at,last_seen_at,started_at)>=?
        ORDER BY student_id,started_at""",
        (end_utc.isoformat(), start_utc.isoformat()),
    )
    crossings = fetchall(
        """SELECT student_id,direction,event_at FROM office_crossing_events
        WHERE event_at>=? AND event_at<? ORDER BY event_at""",
        (start_utc.isoformat(), end_utc.isoformat()),
    )
    # V5: per-employee shift assignments and auditable corrections. These tables
    # may not exist on an older install, so report generation remains backward compatible.
    employee_shift_map: dict[int, dict] = {}
    corrections_by_day: dict[tuple[int, date], dict] = {}
    try:
        for sh in fetchall("""SELECT a.student_id,s.shift_name,s.start_time,s.end_time,s.late_grace_minutes,s.early_leave_grace_minutes,s.workdays_json
                            FROM employee_shift_assignments a JOIN work_shifts s ON s.id=a.shift_id WHERE s.active=1"""):
            try:
                days = json.loads(sh.get("workdays_json") or "[]")
            except Exception:
                days = [0,1,2,3,4,5]
            employee_shift_map[int(sh.get("student_id") or 0)] = {
                "enabled": True,
                "name": str(sh.get("shift_name") or "Ca làm"),
                "start_time": str(sh.get("start_time") or "08:00"),
                "end_time": str(sh.get("end_time") or "17:30"),
                "break_start": "12:00", "break_end": "12:00",
                "late_grace_minutes": int(sh.get("late_grace_minutes") or 0),
                "early_leave_grace_minutes": int(sh.get("early_leave_grace_minutes") or 0),
                "workdays": [int(x) for x in days],
            }
        corr_rows = fetchall("""SELECT * FROM attendance_corrections_v5 WHERE work_date>=? AND work_date<=? ORDER BY created_at""",
                             (start_date.isoformat(), (end_utc - timedelta(microseconds=1)).astimezone(VN_TZ).date().isoformat()))
        for c in corr_rows:
            try:
                key = (int(c.get("student_id") or 0), date.fromisoformat(str(c.get("work_date") or "")))
                corrections_by_day[key] = c  # latest row wins due created_at order
            except Exception:
                pass
    except Exception:
        employee_shift_map = {}
        corrections_by_day = {}

    by_emp_day: dict[tuple[int, date], dict] = {}
    for row in sessions:
        sid = int(row.get("student_id") or 0)
        sdt = _parse_dt(row.get("started_at"))
        if not sid or not sdt:
            continue
        if str(row.get("status") or "").upper() == "OPEN":
            edt = min(effective_end, now_utc)
        else:
            edt = _parse_dt(row.get("ended_at")) or _parse_dt(row.get("last_seen_at")) or sdt
        seg_start = max(sdt, start_utc)
        seg_end = min(edt, end_utc)
        if seg_end <= seg_start:
            continue
        for d, a, b in _split_local_days(seg_start, seg_end):
            key = (sid, d)
            bucket = by_emp_day.setdefault(key, {"segments": [], "out_events": 0})
            bucket["segments"].append((a, b))

    for ev in crossings:
        if str(ev.get("direction") or "").upper() != "OUT":
            continue
        sid = int(ev.get("student_id") or 0)
        edt = _parse_dt(ev.get("event_at"))
        if not sid or not edt:
            continue
        d = edt.astimezone(VN_TZ).date()
        if start_utc <= edt < end_utc:
            by_emp_day.setdefault((sid, d), {"segments": [], "out_events": 0})["out_events"] += 1

    report_days = []
    d = start_utc.astimezone(VN_TZ).date()
    last_date = (end_utc - timedelta(microseconds=1)).astimezone(VN_TZ).date()
    while d <= last_date:
        report_days.append(d)
        d += timedelta(days=1)

    rows = []
    totals = {
        "employee_count": len(employees),
        "present_employees": 0,
        "absent_employees": 0,
        "presence_seconds": 0.0,
        "outside_seconds": 0.0,
        "out_events": 0,
        "late_cases": 0,
        "early_leave_cases": 0,
        "present_days": 0,
        "absent_days": 0,
    }
    for emp in employees:
        sid = int(emp["id"])
        emp_presence = 0.0
        emp_outside = 0.0
        emp_sessions = 0
        emp_out_events = 0
        late_days = 0
        early_days = 0
        present_days = 0
        absent_days = 0
        first_seen: datetime | None = None
        last_seen: datetime | None = None
        camera_first_seen: datetime | None = None
        camera_last_seen: datetime | None = None
        expected_total = 0.0
        emp_policy = employee_shift_map.get(sid) or policy

        for d in report_days:
            bucket = by_emp_day.get((sid, d), {"segments": [], "out_events": 0})
            segments = sorted(bucket.get("segments") or [], key=lambda x: x[0])
            # Merge overlapping segments before calculating time/gaps.
            merged: list[list[datetime]] = []
            for a, b in segments:
                if not merged or a > merged[-1][1]:
                    merged.append([a, b])
                elif b > merged[-1][1]:
                    merged[-1][1] = b
            presence = sum((b - a).total_seconds() for a, b in merged)
            outside = 0.0
            for i in range(1, len(merged)):
                outside += max(0.0, (merged[i][0] - merged[i - 1][1]).total_seconds())
            day_first = merged[0][0] if presence > 0 else None
            day_last = merged[-1][1] if presence > 0 else None
            if day_first:
                camera_first_seen = day_first if camera_first_seen is None or day_first < camera_first_seen else camera_first_seen
                camera_last_seen = day_last if camera_last_seen is None or day_last > camera_last_seen else camera_last_seen

            correction = corrections_by_day.get((sid, d))
            effective_first = _parse_dt(correction.get("effective_checkin_at")) if correction else None
            effective_last = _parse_dt(correction.get("effective_checkout_at")) if correction else None
            # A correction changes the business attendance result, never the camera
            # evidence. If only check-in was adjusted, checkout still comes from camera.
            business_first = effective_first.astimezone(VN_TZ) if effective_first else day_first
            business_last = effective_last.astimezone(VN_TZ) if effective_last else day_last
            has_attendance = bool(presence > 0 or business_first or business_last)
            if has_attendance:
                present_days += 1
                emp_sessions += len(merged)
                if business_first:
                    first_seen = business_first if first_seen is None or business_first < first_seen else first_seen
                if business_last:
                    last_seen = business_last if last_seen is None or business_last > last_seen else last_seen

            is_workday = d.weekday() in set(emp_policy.get("workdays") or [])
            today_local = datetime.now(VN_TZ).date()
            if emp_policy.get("enabled") and is_workday and d <= today_local:
                shift = _shift_times_for_day(d, emp_policy)
                expected_total += shift["expected_sec"]
                if not has_attendance:
                    absent_days += 1
                if has_attendance and business_first:
                    late_cutoff = shift["start"] + timedelta(minutes=int(emp_policy.get("late_grace_minutes") or 0))
                    if business_first > late_cutoff:
                        late_days += 1
                if has_attendance and business_last:
                    # Do not call an in-progress current shift "early leave".
                    current_local = datetime.now(VN_TZ)
                    shift_complete = d < current_local.date() or current_local >= shift["end"]
                    early_cutoff = shift["end"] - timedelta(minutes=int(emp_policy.get("early_leave_grace_minutes") or 0))
                    if shift_complete and business_last < early_cutoff:
                        early_days += 1
            emp_presence += presence
            emp_outside += outside
            emp_out_events += int(bucket.get("out_events") or 0)

        if present_days > 0:
            totals["present_employees"] += 1
        else:
            totals["absent_employees"] += 1
        totals["presence_seconds"] += emp_presence
        totals["outside_seconds"] += emp_outside
        totals["out_events"] += emp_out_events
        totals["late_cases"] += late_days
        totals["early_leave_cases"] += early_days
        totals["present_days"] += present_days
        totals["absent_days"] += absent_days

        if not emp_policy.get("enabled"):
            status = "Có mặt" if present_days > 0 else "Chưa ghi nhận"
        elif present_days <= 0:
            status = "Vắng" if absent_days > 0 else "Chưa ghi nhận"
        elif late_days > 0 and early_days > 0:
            status = "Đi muộn · Rời sớm"
        elif late_days > 0:
            status = "Đi muộn"
        elif early_days > 0:
            status = "Rời sớm"
        else:
            status = "Đúng giờ"
        compliance = round(min(100.0, (emp_presence / expected_total * 100.0) if expected_total > 0 else 0.0), 1) if emp_policy.get("enabled") else None
        rows.append({
            "student_id": sid,
            "employee_code": str(emp.get("student_code") or ""),
            "full_name": str(emp.get("full_name") or ""),
            "department": str(emp.get("faculty") or ""),
            "position": str(emp.get("class_name") or ""),
            "first_seen": _fmt_time(first_seen),
            "last_seen": _fmt_time(last_seen),
            "camera_first_seen": _fmt_time(camera_first_seen),
            "camera_last_seen": _fmt_time(camera_last_seen),
            "attendance_adjusted": any(k[0] == sid for k in corrections_by_day.keys()),
            "shift_name": str(emp_policy.get("name") or ""),
            "shift_start": str(emp_policy.get("start_time") or ""),
            "shift_end": str(emp_policy.get("end_time") or ""),
            "presence_seconds": round(emp_presence, 1),
            "presence_text": _fmt_seconds(emp_presence),
            "outside_seconds": round(emp_outside, 1),
            "outside_text": _fmt_seconds(emp_outside),
            "session_count": emp_sessions,
            "out_count": emp_out_events,
            "present_days": present_days,
            "absent_days": absent_days,
            "late_days": late_days,
            "early_leave_days": early_days,
            "compliance_percent": compliance,
            "status": status,
        })

    totals.update({
        "presence_text": _fmt_seconds(totals["presence_seconds"]),
        "outside_text": _fmt_seconds(totals["outside_seconds"]),
    })
    return {
        "period": str(period or "day").lower(),
        "anchor": start_date.isoformat(),
        "label": label,
        "generated_at": utc_now(),
        "timezone": "Asia/Ho_Chi_Minh",
        "shift_policy": policy,
        "totals": totals,
        "rows": rows,
    }


def _xml_escape(value: Any) -> str:
    return escape(str(value if value is not None else ""), quote=False)


def _xlsx_sheet_xml(data: list[list[Any]]) -> str:
    def col_name(n: int) -> str:
        s = ""
        while n:
            n, r = divmod(n - 1, 26)
            s = chr(65 + r) + s
        return s
    rows = []
    for r_idx, row in enumerate(data, 1):
        cells = []
        for c_idx, value in enumerate(row, 1):
            ref = f"{col_name(c_idx)}{r_idx}"
            if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value)):
                cells.append(f'<c r="{ref}"><v>{value}</v></c>')
            else:
                cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{_xml_escape(value)}</t></is></c>')
        rows.append(f'<row r="{r_idx}">' + "".join(cells) + "</row>")
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' \
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' \
        '<sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/>' \
        '<sheetData>' + "".join(rows) + '</sheetData></worksheet>'


def report_xlsx_bytes(report: dict) -> bytes:
    rows = report.get("rows") or []
    summary = [
        ["CampusFace - Báo cáo nhân sự"],
        ["Kỳ báo cáo", report.get("label")],
        ["Múi giờ", report.get("timezone")],
        ["Nhân viên", int((report.get("totals") or {}).get("employee_count") or 0)],
        ["Có mặt", int((report.get("totals") or {}).get("present_employees") or 0)],
        ["Chưa ghi nhận", int((report.get("totals") or {}).get("absent_employees") or 0)],
        ["Tổng hiện diện", (report.get("totals") or {}).get("presence_text")],
        ["Tổng ra ngoài", (report.get("totals") or {}).get("outside_text")],
        [],
        ["Mã NV", "Họ tên", "Phòng ban", "Chức vụ/Bộ phận", "Đầu", "Cuối", "Hiện diện", "Ra ngoài", "Phiên", "OUT", "Ngày có mặt", "Đi muộn", "Rời sớm", "Tuân thủ %", "Trạng thái"],
    ]
    for r in rows:
        summary.append([
            r.get("employee_code"), r.get("full_name"), r.get("department"), r.get("position"),
            r.get("first_seen"), r.get("last_seen"), r.get("presence_text"), r.get("outside_text"),
            int(r.get("session_count") or 0), int(r.get("out_count") or 0), int(r.get("present_days") or 0),
            int(r.get("late_days") or 0), int(r.get("early_leave_days") or 0),
            r.get("compliance_percent") if r.get("compliance_percent") is not None else "—", r.get("status"),
        ])
    policy = report.get("shift_policy") or {}
    shift = [
        ["Quy tắc ca làm việc"],
        ["Trạng thái", "Bật" if policy.get("enabled") else "Tắt"],
        ["Tên ca", policy.get("name")],
        ["Giờ vào", policy.get("start_time")],
        ["Giờ ra", policy.get("end_time")],
        ["Nghỉ", f"{policy.get('break_start')} - {policy.get('break_end')}"],
        ["Cho phép đi muộn", f"{policy.get('late_grace_minutes')} phút"],
        ["Cho phép rời sớm", f"{policy.get('early_leave_grace_minutes')} phút"],
    ]
    out = BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Báo cáo" sheetId="1" r:id="rId1"/><sheet name="Ca làm việc" sheetId="2" r:id="rId2"/></sheets></workbook>')
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>')
        z.writestr("xl/worksheets/sheet1.xml", _xlsx_sheet_xml(summary))
        z.writestr("xl/worksheets/sheet2.xml", _xlsx_sheet_xml(shift))
    return out.getvalue()


def report_print_html(report: dict) -> str:
    totals = report.get("totals") or {}
    rows = report.get("rows") or []
    policy = report.get("shift_policy") or {}
    body_rows = []
    for r in rows:
        body_rows.append(
            "<tr>"
            f"<td>{escape(str(r.get('employee_code') or ''))}</td>"
            f"<td><b>{escape(str(r.get('full_name') or ''))}</b></td>"
            f"<td>{escape(str(r.get('department') or '—'))}</td>"
            f"<td>{escape(str(r.get('first_seen') or '—'))}</td>"
            f"<td>{escape(str(r.get('last_seen') or '—'))}</td>"
            f"<td>{escape(str(r.get('presence_text') or '—'))}</td>"
            f"<td>{escape(str(r.get('outside_text') or '—'))}</td>"
            f"<td>{int(r.get('late_days') or 0)}</td>"
            f"<td>{escape(str(r.get('status') or ''))}</td>"
            "</tr>"
        )
    shift_text = "Chưa bật" if not policy.get("enabled") else f"{policy.get('name')} · {policy.get('start_time')}–{policy.get('end_time')}"
    return f'''<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>CampusFace - Báo cáo nhân sự</title>
<style>body{{font-family:Arial,"Segoe UI",sans-serif;color:#152d2b;margin:28px}}h1{{margin:0 0 4px;font-size:24px}}.muted{{color:#6b7c7a}}.kpi{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0}}.kpi div{{border:1px solid #dce7e5;border-radius:10px;padding:10px}}.kpi b{{display:block;font-size:20px;margin-top:4px}}table{{width:100%;border-collapse:collapse;font-size:11px}}th,td{{border-bottom:1px solid #e2e9e8;padding:8px;text-align:left}}th{{background:#f2f7f6}}.foot{{margin-top:16px;font-size:10px;color:#71827f}}@media print{{button{{display:none}}body{{margin:12mm}}}}</style></head><body>
<h1>CampusFace · Báo cáo nhân sự</h1><div class="muted">Kỳ báo cáo: {escape(str(report.get('label') or ''))} · {escape(shift_text)}</div>
<div class="kpi"><div>Nhân viên<b>{int(totals.get('employee_count') or 0)}</b></div><div>Có mặt<b>{int(totals.get('present_employees') or 0)}</b></div><div>Tổng hiện diện<b>{escape(str(totals.get('presence_text') or '0h'))}</b></div><div>Đi muộn<b>{int(totals.get('late_cases') or 0)}</b></div></div>
<table><thead><tr><th>Mã NV</th><th>Họ tên</th><th>Phòng ban</th><th>Đầu</th><th>Cuối</th><th>Hiện diện</th><th>Ra ngoài</th><th>Muộn</th><th>Trạng thái</th></tr></thead><tbody>{''.join(body_rows)}</tbody></table>
<div class="foot">Tạo lúc {escape(str(report.get('generated_at') or ''))} · Múi giờ Asia/Ho_Chi_Minh · Dữ liệu từ Presence Session và Virtual Gate.</div>
<script>window.addEventListener('load',()=>setTimeout(()=>window.print(),180));</script></body></html>'''
