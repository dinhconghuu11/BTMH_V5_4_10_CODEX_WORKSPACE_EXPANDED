(()=>{
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let sourceItems=[],authReady=false,authEpoch=0,pageEpoch=0,fleetSignature="",fleetController=null;
let v4Fleet=[],v4Layout=2,v4EnrollmentStream=null,v4EnrollmentCanvas=null,selectedPlaybackSegment=null,modalCameraId=null;
function token(){return localStorage.getItem('campusface_token')||''}
async function v4api(url,opts={}){const headers={'Content-Type':'application/json',...(opts.headers||{})};const t=token();if(t)headers.Authorization='Bearer '+t;const r=await BTMHRuntime.request(url,{...opts,headers,timeoutMs:opts.method?90000:12000});let j={};try{j=await r.json()}catch(_){}if(!r.ok)throw new Error(j.detail||j.message||('Lỗi '+r.status));return j}
function esc(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function streamUrl(id){return `/api/v1/cameras/${encodeURIComponent(id)}/stream.mjpg?ts=${Date.now()}`}
function cameraName(c){return c.name||c.camera_name||`CAM${c.id||''}`}
function formatLocal(v){if(!v)return '—';try{return new Date(v).toLocaleString('vi-VN')}catch(_){return v}}
function toLocalInput(v){if(!v)return '';const d=new Date(v);if(Number.isNaN(d.getTime()))return '';const z=n=>String(n).padStart(2,'0');return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}T${z(d.getHours())}:${z(d.getMinutes())}:${z(d.getSeconds())}`}

function cameraAllowed(){return authReady&&typeof hasUiPermission==='function'&&hasUiPermission('camera.live');}
async function loadSources(){
  if(!cameraAllowed())return;
  return BTMHRuntime.once('camera-sources',async()=>{
    const epoch=authEpoch;
    try{
      const d=await v4api('/api/v1/camera/sources');if(epoch!==authEpoch||!authReady)return;
      sourceItems=d.items||[];populateCameraSwitchers();
      for(const el of $$('[data-source-note]'))el.textContent=sourceItems.filter(x=>x.source_key!=='0').length?'Camera ch\u01b0a k\u1ebft n\u1ed1i v\u1eabn hi\u1ec7n trong danh s\u00e1ch.':'Ch\u01b0a khai b\u00e1o camera c\u1eeda h\u00e0ng. Ch\u1ecdn Qu\u1ea3n l\u00fd camera \u0111\u1ec3 th\u00eam.';
      return d;
    }catch(e){for(const el of $$('[data-source-note]'))el.textContent='Kh\u00f4ng t\u1ea3i \u0111\u01b0\u1ee3c danh s\u00e1ch camera. B\u1ea5m T\u1ea3i l\u1ea1i.';}
  });
}
async function loadV4Fleet(){
  if(!cameraAllowed()||!$('#page-live-grid.active')||document.hidden)return;
  return BTMHRuntime.once('camera-fleet',async()=>{
    const epoch=pageEpoch;fleetController=new AbortController();
    try{
      const d=await v4api('/api/v1/cameras/fleet/v4',{signal:fleetController.signal});
      if(epoch!==pageEpoch||!$('#page-live-grid.active')||!authReady)return;
      v4Fleet=d.items||[];renderV4Grid();renderV4CameraRoles(d);await loadSources();
    }catch(e){if(e.name!=='AbortError'&&epoch===pageEpoch){const h=$('#v4CameraGrid');if(h)h.innerHTML=`<div class="v4-empty">${esc(e.message)}</div>`;fleetSignature='';}}
    finally{fleetController=null;}
  });
}
function renderV4CameraRoles(data={}){const enroll=$('#v4EnrollmentCameraName'),surv=$('#v4SurveillanceCameraName'),survState=$('#v4SurveillanceCameraState');if(enroll)enroll.textContent='Laptop Camera';const primary=(data.items||[]).find(x=>x.role==='SURVEILLANCE_PRIMARY')||(data.items||[])[0];if(surv)surv.textContent=primary?cameraName(primary):'Chưa cấu hình camera cửa hàng';if(survState){if(!primary)survState.textContent='Chờ camera';else if(!primary.online)survState.textContent='Offline';else if(primary.recording_active)survState.textContent='Online · REC';else survState.textContent='Online · REC đang khởi động';}}
function renderV4Grid(){
  const host=$('#v4CameraGrid');if(!host||!$('#page-live-grid.active'))return;
  host.className=`v4-camera-grid cols-${v4Layout}`;
  const signature=JSON.stringify([v4Layout,v4Fleet.map(c=>[c.id,c.name,c.online,c.enabled,c.recording_active,c.zone_name])]);
  if(signature!==fleetSignature){
    host.querySelectorAll('[data-fleet-preview]').forEach(i=>{window.BTMHMedia?.stop?.(`grid-${i.dataset.fleetPreview}`);BTMHRuntime.stopPreview(i);});fleetSignature=signature;
    host.innerHTML=v4Fleet.length?v4Fleet.map(c=>{
      const id=Number(c.id),online=!!c.online;
      return `<article class="v4-camera-card" data-camera-id="${id}" tabindex="0" role="button" aria-label="${esc(cameraName(c))}">${online?`<img data-fleet-preview="${id}" alt="${esc(cameraName(c))}">`:`<div class="placeholder"><strong>${esc(cameraName(c))}</strong><p>${c.enabled===false?'\u0110\u00e3 t\u1eaft':'\u0110ang k\u1ebft n\u1ed1i / ch\u01b0a c\u00f3 h\u00ecnh'}</p></div>`}<div class="meta"><div><b>${esc(cameraName(c))}</b><small>${esc(c.zone_name||'Camera c\u1eeda h\u00e0ng')}</small></div><div class="flags"><span>${online?'Tr\u1ef1c tuy\u1ebfn':'Ch\u01b0a k\u1ebft n\u1ed1i'}</span>${c.recording_active?'<span class="rec">\u0110ang ghi</span>':''}</div></div></article>`;
    }).join(''):'<div class="v4-empty">Ch\u01b0a khai b\u00e1o camera c\u1eeda h\u00e0ng. Th\u00eam camera trong Qu\u1ea3n l\u00fd camera.</div>';
    host.querySelectorAll('.v4-camera-card').forEach(el=>{el.addEventListener('click',()=>openV4Camera(Number(el.dataset.cameraId)));el.addEventListener('keydown',e=>{if(e.key==='Enter')openV4Camera(Number(el.dataset.cameraId));});});
  }
  host.querySelectorAll('[data-fleet-preview]').forEach(i=>{
    const id=Number(i.dataset.fleetPreview),key=`grid-${id}`;
    if(modalCameraId===id)return;
    if(window.BTMHMedia){
      if(BTMHMedia.stats()[key])return;
      const wrap=i.closest('.v4-camera-card');wrap.querySelector('.meta').style.zIndex='2';
      BTMHMedia.mount(key,{cameraId:id,wrap,image:i,fit:'contain',allowMjpeg:false,pollInterval:400,mjpegUrl:`/api/v1/cameras/${id}/stream.mjpg`,pollUrl:`/api/v1/cameras/${id}/frame.jpg`});
    }else BTMHRuntime.preview(i,`/api/v1/cameras/${id}/frame.jpg`,400);
  });
}
function openV4Camera(id){
  const c=v4Fleet.find(x=>Number(x.id)===id);if(!c)return;const modal=$('#v4CameraModal');if(!modal)return;
  closeV4Camera(false);modalCameraId=id;window.BTMHMedia?.stop?.(`grid-${id}`);renderV4Grid();
  $('#v4CameraModalTitle').textContent=cameraName(c);$('#v4CameraModalMeta').textContent=c.zone_name||'';modal.classList.remove('hidden');
  if(c.online){if(window.BTMHMedia)BTMHMedia.mount('grid-modal',{cameraId:id,wrap:'#v4CameraModalViewport',image:'#v4CameraModalStream',fit:'contain',mjpegUrl:`/api/v1/cameras/${id}/stream.mjpg`,pollUrl:`/api/v1/cameras/${id}/frame.jpg`});else BTMHRuntime.preview($('#v4CameraModalStream'),`/api/v1/cameras/${id}/frame.jpg`,90);}
}
function closeV4Camera(resume=true){const m=$('#v4CameraModal');if(m)m.classList.add('hidden');window.BTMHMedia?.stop?.('grid-modal');BTMHRuntime.stopPreview($('#v4CameraModalStream'));modalCameraId=null;if(resume&&cameraAllowed()&&!document.hidden&&$('#page-live-grid.active'))renderV4Grid();}
function renderGridPlayback(d={}){
  const match=/^grid-(\d+)$/.exec(d.key||''),fps=Number.isFinite(d.renderedFps)?`${Math.round(d.renderedFps)} FPS`:'FPS —';
  if(match){const badge=document.querySelector(`[data-camera-id="${match[1]}"] .flags span`);if(badge){badge.textContent=d.state==='live'?`${d.transport} · ${fps}`:'Đang kết nối';badge.title=d.fallbackReason?`Fallback: ${d.fallbackReason}`:d.transport||'';}}
  if(d.key==='grid-modal'){const meta=$('#v4CameraModalMeta');if(meta){const c=v4Fleet.find(x=>Number(x.id)===modalCameraId);meta.textContent=[c?.zone_name,d.transport,fps,d.fallbackReason?`Fallback: ${d.fallbackReason}`:''].filter(Boolean).join(' · ');}}
}
document.addEventListener('btmh:media-state',e=>renderGridPlayback(e.detail));
document.addEventListener('btmh:media-stats',e=>renderGridPlayback(e.detail));
function bindLayout(){$$('[data-v4-layout]').forEach(b=>b.addEventListener('click',()=>{v4Layout=Number(b.dataset.v4Layout)||2;$$('[data-v4-layout]').forEach(x=>x.classList.toggle('active',x===b));renderV4Grid()}));$('#v4CameraModalClose')?.addEventListener('click',closeV4Camera);$('#v4CameraModal')?.addEventListener('click',e=>{if(e.target.id==='v4CameraModal')closeV4Camera()})}

function sourceLabel(c){const tag=c.enabled===false?'\u0111\u00e3 t\u1eaft':c.health_status==='ONLINE'?'\u0111ang d\u00f9ng':c.health_status==='OFFLINE'?'m\u1ea5t k\u1ebft n\u1ed1i':c.health_status==='INVALID'?'ch\u01b0a c\u1ea5u h\u00ecnh':'ch\u01b0a ki\u1ec3m tra';return `${c.name} \u00b7 ${tag}`;}
function populateSelect(sel,includeBrowser=false){
  if(!sel)return;
  const current=sel.value,first=sel.dataset.sourcesLoaded!=='1';
  const opts=sourceItems.map(c=>({...c,value:c.source_key,label:sourceLabel(c)}));
  if(includeBrowser)opts.unshift({value:'browser',label:'Camera laptop (tr\u00ecnh duy\u1ec7t)',selectable:true});
  sel.innerHTML=opts.map(o=>`<option value="${esc(o.value)}" ${o.selectable===false?'disabled':''}>${esc(o.label)}</option>`).join('');
  const active=opts.find(o=>o.active);
  if(first&&active&&!includeBrowser)sel.value=active.value;
  else if(opts.some(o=>o.value===current))sel.value=current;
  sel.dataset.sourcesLoaded='1';
}
function populateCameraSwitchers(){populateSelect($('#v5ActiveCameraSelect'));populateSelect($('#v5RecognitionCameraSelect'));populateSelect($('#v5EnrollmentCameraSelect'),true);populatePlayback();}
function populatePlayback(){const sel=$('#v4PlaybackCamera');if(!sel)return;const current=sel.value;sel.innerHTML='<option value="">Ch\u1ecdn camera</option>'+sourceItems.map(c=>`<option value="${esc(c.source_key)}">${esc(c.name)}</option>`).join('');if([...sel.options].some(o=>o.value===current))sel.value=current;}
async function refreshActiveCameraStatus(){await loadSources();const active=sourceItems.find(c=>c.active);const el=$('#v5ActiveCameraLabel');if(el)el.textContent=active?.name||'Camera hi\u1ec7n t\u1ea1i';}
async function switchCameraSource(sel,btn,note){
  if(!sel||!cameraAllowed())return;
  if(window.BTMHCameraTools)return BTMHCameraTools.switchSource(sel,btn,note);
  if(note)note.textContent='Tai giao dien moi bang Ctrl+F5 de su dung cong cu camera.';
}
async function switchActiveCamera(){return switchCameraSource($('#v5ActiveCameraSelect'),$('#v5SwitchCameraBtn'),$('#v5CameraSwitchNote'));}
async function switchRecognitionCamera(){return switchCameraSource($('#v5RecognitionCameraSelect'),$('#v5RecognitionSwitchBtn'),$('#v5RecognitionCameraNote'));}
async function loadPresenceV4(){const host=$('#v4PresenceList');if(!host)return;try{const d=await v4api('/api/v1/presence/current');const rows=d.items||[];$('#v4PresenceNow').textContent=rows.length;$('#v4PresenceTotal').textContent=d.employee_total??'—';$('#v4PresenceAway').textContent=Math.max(0,Number(d.employee_total||0)-rows.length);$('#v4PresenceVisitors').textContent=d.active_visitors??0;host.innerHTML=rows.length?rows.map(r=>`<div class="v4-presence-row"><div><b>${esc(r.full_name||'Nhân viên')}</b><small>${esc(r.employee_code||'')} · ${esc(r.department||'')}</small></div><span class="v4-state-present">● Đang có mặt</span><span>Lần cuối: ${esc(formatLocal(r.last_seen_at||r.started_at))}</span></div>`).join(''):'<div class="v4-empty">Chưa ghi nhận nhân viên đang có mặt.</div>'}catch(e){host.innerHTML=`<div class="v4-empty">${esc(e.message)}</div>`}}

async function loadPlaybackV4(){await loadSources();populatePlayback();}
async function searchPlaybackV4(){const source=$('#v4PlaybackCamera')?.value||'',date=$('#v4PlaybackDate')?.value||'',host=$('#v4PlaybackResults');if(!source||!date){host.innerHTML='<div class="v4-empty">Chọn camera và ngày để xem bản ghi.</div>';return}const localStart=new Date(`${date}T00:00:00`),localEnd=new Date(`${date}T23:59:59.999`),start=localStart.toISOString(),end=localEnd.toISOString();try{const d=await v4api(`/api/v1/recordings/segments?camera_source=${encodeURIComponent(source)}&start_at=${encodeURIComponent(start)}&end_at=${encodeURIComponent(end)}&limit=500`);const rows=d.items||[];if(rows.length){host.innerHTML=rows.map((r,i)=>`<button class="btn ghost" data-v4-segment="${i}" style="width:100%;margin-bottom:8px;text-align:left">${esc(formatLocal(r.start_at))} → ${esc(formatLocal(r.end_at))}${r.protected?' · EVIDENCE':''}</button>`).join('');$$('[data-v4-segment]').forEach(b=>b.addEventListener('click',()=>playSegment(rows[Number(b.dataset.v4Segment)])));return}let msg='Chưa có đoạn video đã hoàn tất trong ngày này. Segment đang ghi chỉ xuất hiện sau khi file MP4 được đóng.';try{const st=await v4api('/api/v1/recordings/status'),cam=st?.runtime?.cameras?.[source]||{};if(st?.runtime?.ready===false)msg='FFmpeg recorder chưa sẵn sàng trên máy này.';else if(cam.active===false&&cam.last_error)msg=`Recorder chưa chạy: ${cam.last_error}`;else if(cam.active)msg='Recorder đang chạy. Đoạn video đầu tiên sẽ xuất hiện sau khoảng 1 phút.';}catch(_){}host.innerHTML=`<div class="v4-empty">${esc(msg)}</div>`;}catch(e){host.innerHTML=`<div class="v4-empty">${esc(e.message)}</div>`}}
function playSegment(r){selectedPlaybackSegment=r||null;const v=$('#v4PlaybackVideo'),empty=$('#v4PlaybackEmpty'),clipBtn=$('#v5CreateClipBtn');if(clipBtn)clipBtn.disabled=!r;if($('#v5ClipStart'))$('#v5ClipStart').value=toLocalInput(r?.start_at);if($('#v5ClipEnd'))$('#v5ClipEnd').value=toLocalInput(r?.end_at);if($('#v5ClipState'))$('#v5ClipState').textContent=r?`Đã chọn segment ${r.segment_id||''}.`:'Chưa chọn segment.';if(!v)return;const uri=String(r?.media_uri||'');if(!uri){empty.textContent='Segment đã được index nhưng nguồn media hiện chưa phát trực tiếp được.';empty.style.display='block';v.style.display='none';return}let url=uri;if(!/^https?:\/\//i.test(uri)&&!uri.startsWith('/'))url=`/api/v1/recordings/media?path=${encodeURIComponent(uri)}`;v.onerror=()=>{empty.textContent='Không phát được MP4 này. Hãy kiểm tra camera đang dùng H.264 (không phải H.265/H.265+) và recorder đã đóng segment hoàn chỉnh.';empty.style.display='block';v.style.display='none';};v.src=url;v.load();v.style.display='block';empty.style.display='none';v.play().catch(()=>{})}
async function createClip(){const state=$('#v5ClipState'),btn=$('#v5CreateClipBtn');if(!selectedPlaybackSegment)return;btn&&(btn.disabled=true);try{const start=$('#v5ClipStart')?.value||'',end=$('#v5ClipEnd')?.value||'';if(!start||!end)throw new Error('Hãy chọn thời gian bắt đầu và kết thúc.');const out=await v4api('/api/v1/video/clips',{method:'POST',body:JSON.stringify({segment_id:String(selectedPlaybackSegment.segment_id||''),start_at:new Date(start).toISOString(),end_at:new Date(end).toISOString()})});const c=out.clip||{};state&&(state.textContent=c.status==='READY'?`Đã tạo clip ${c.clip_id} và lưu media.`:`Đã index clip ${c.clip_id}; nguồn NVR/remote sẽ được lấy theo khoảng thời gian khi cần.`);window.toast?.(`Đã tạo ${c.clip_id||'clip'}.`)}catch(e){state&&(state.textContent=e.message);window.toast?.(e.message,true)}finally{btn&&(btn.disabled=false)}}

async function startEnrollmentBrowserCamera(){const video=$('#enrollVideo');if(!video||!navigator.mediaDevices?.getUserMedia)return false;if(v4EnrollmentStream&&v4EnrollmentStream.active){video.srcObject=v4EnrollmentStream;return true}try{v4EnrollmentStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:1280},height:{ideal:720}},audio:false});if(!$('#page-register.active')||!authReady){stopEnrollmentBrowserCamera();return false;}video.srcObject=v4EnrollmentStream;video.style.display='block';video.play().catch(()=>{});$('#enrollEmpty')?.classList.add('hidden');return true}catch(e){console.warn('Enrollment webcam',e);return false}}
function stopEnrollmentBrowserCamera(){if(v4EnrollmentStream){v4EnrollmentStream.getTracks().forEach(t=>t.stop());v4EnrollmentStream=null}const v=$('#enrollVideo');if(v){v.srcObject=null;v.style.display='none'}}
function enrollmentDataUrl(){const video=$('#enrollVideo');if(!video||!video.videoWidth)return '';if(!v4EnrollmentCanvas)v4EnrollmentCanvas=document.createElement('canvas');const maxW=960,scale=Math.min(1,maxW/video.videoWidth);v4EnrollmentCanvas.width=Math.round(video.videoWidth*scale);v4EnrollmentCanvas.height=Math.round(video.videoHeight*scale);const ctx=v4EnrollmentCanvas.getContext('2d');ctx.drawImage(video,0,0,v4EnrollmentCanvas.width,v4EnrollmentCanvas.height);return v4EnrollmentCanvas.toDataURL('image/jpeg',.86)}
function leavePage(next){
  pageEpoch++;fleetController?.abort();closeV4Camera(false);
  $('#v4CameraGrid')?.querySelectorAll('[data-fleet-preview]').forEach(i=>{window.BTMHMedia?.stop?.(`grid-${i.dataset.fleetPreview}`);BTMHRuntime.stopPreview(i);});
  if(next!=='register')stopEnrollmentBrowserCamera();
  if(next!=='playback'){const v=$('#v4PlaybackVideo');if(v){v.pause();v.removeAttribute('src');v.load();}}
}
window.BTMHV4={loadFleet:loadV4Fleet,loadPresence:loadPresenceV4,loadPlayback:loadPlaybackV4,loadSources,leavePage,startEnrollmentBrowserCamera,stopEnrollmentBrowserCamera,enrollmentDataUrl,refreshActiveCameraStatus};
document.addEventListener('btmh:auth',e=>{
  authEpoch++;authReady=!!e.detail?.authenticated;
  if(authReady){void loadSources();}else{leavePage('signed-out');sourceItems=[];v4Fleet=[];fleetSignature='';}
});
document.addEventListener('btmh:navigate',e=>{if(['recognition','register','live-grid','playback','system'].includes(e.detail?.page))void loadSources();});
document.addEventListener('btmh:camera-registry-changed',()=>void loadSources());
document.addEventListener('DOMContentLoaded',()=>{
  bindLayout();$('#v4PlaybackSearch')?.addEventListener('click',searchPlaybackV4);$('#v4PlaybackRefresh')?.addEventListener('click',loadPlaybackV4);$('#v5SwitchCameraBtn')?.addEventListener('click',switchActiveCamera);$('#v5RecognitionSwitchBtn')?.addEventListener('click',switchRecognitionCamera);$('#v5CreateClipBtn')?.addEventListener('click',createClip);
  document.querySelectorAll('[data-refresh-sources]').forEach(b=>b.addEventListener('click',()=>void loadSources()));
  if($('#v4PlaybackDate'))$('#v4PlaybackDate').value=new Date().toISOString().slice(0,10);
  // Never issue authenticated fleet/playback requests before login.
  setInterval(()=>{if(!authReady||document.hidden)return;if($('#page-live-grid.active'))void loadV4Fleet();if($('#page-operations.active'))BTMHRuntime.once('presence',loadPresenceV4).catch(()=>{});},5000);
});
})();
