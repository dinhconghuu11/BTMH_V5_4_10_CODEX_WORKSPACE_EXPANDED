'use strict';
const assert = require('node:assert/strict');
const test = require('node:test');
const {createController, comparisonText, publicRecent, visitLabels} = require('../frontend/js/btmh_management.js');
function fixture() {
  let allowed = true, timer, timerCount = 0, cleared = 0;
  const requests = [], delivered = [], errors = [];
  const controller = createController({eligible: () => allowed, request: options => new Promise((resolve,reject) => requests.push({options,resolve,reject})),
    success: data => delivered.push(data), error: reason => errors.push(reason),
    setTimer: callback => {timer = callback; timerCount++; return 1;}, clearTimer: () => {cleared++;}});
  return {controller,requests,delivered,errors,setAllowed: value => {allowed=value;}, tick:()=>timer(), timers:()=>timerCount, cleared:()=>cleared};
}
const settle = async () => {await Promise.resolve(); await Promise.resolve();};
test('same page polling remains single-flight with one interval', async () => {const f=fixture(); f.controller.start(); f.controller.start(); f.tick(); assert.equal(f.requests.length,1); assert.equal(f.timers(),1); f.requests[0].resolve({count:2}); await settle(); assert.equal(f.delivered.length,1); f.controller.stop(); assert.equal(f.cleared(),1);});
test('store switch aborts old request and only newest response can render', async () => {const f=fixture(); f.controller.start(); void f.controller.refresh(true); assert.equal(f.requests.length,2); assert.equal(f.requests[0].options.signal.aborted,true); f.requests[1].resolve('new'); f.requests[0].resolve('old'); await settle(); assert.deepEqual(f.delivered,['new']); f.controller.stop();});
test('logout/navigation aborts current response and timer without cancelling backend AI', async () => {const f=fixture(); f.controller.start(); f.controller.stop(); assert.equal(f.requests[0].options.signal.aborted,true); f.requests[0].resolve('private'); await settle(); assert.deepEqual(f.delivered,[]); assert.equal(f.cleared(),1);});
test('visibility or permission race cannot render private data', async () => {const f=fixture(); f.controller.start(); f.setAllowed(false); f.requests[0].resolve('private'); await settle(); assert.deepEqual(f.delivered,[]); f.controller.stop();});
test('failed request is recoverable and not mistaken for zero business data', async () => {const f=fixture(); f.controller.start(); f.requests[0].reject(new Error('offline')); await settle(); assert.equal(f.errors.length,1); void f.controller.refresh(); f.requests[1].resolve('real'); await settle(); assert.deepEqual(f.delivered,['real']); f.controller.stop();});
test('zero yesterday comparison is explicit without infinity or fabricated percent', () => {assert.equal(comparisonText({change_state:'NEW_ACTIVITY',percent:null}),'Có lượt ghé mới'); assert.equal(comparisonText({change_state:'UNCHANGED',percent:0}),'Không đổi'); assert.equal(comparisonText({percent:null}),'Chưa đủ dữ liệu so sánh');});
test('historical selected date is never labelled as today',()=>{assert.deepEqual(visitLabels({date:'2026-10-07',comparison_date:'2026-10-06'},'2026-10-08'),['2026-10-07','2026-10-06']);assert.deepEqual(visitLabels({date:'2026-10-08',comparison_date:'2026-10-07'},'2026-10-08'),['Hôm nay','Hôm qua']);});
test('unverified identities and raw diagnostic fields never enter management rendering', () => {const data=publicRecent([{full_name:'Candidate name',faceid_status:'CHECKING',camera_source:'secret',detail_json:'secret',store_name:'Hà Đông',camera_name:'Cửa vào'}, {full_name:'Đặng',faceid_status:'VERIFIED',recognized:true}]); assert.equal(data[0].name,'Chưa xác định'); assert.equal(data[1].name,'Đặng'); assert.equal(data[0].location,'Hà Đông · Cửa vào'); assert.equal(JSON.stringify(data).includes('secret'),false);});
